/*@
  predicate Node(Node n; Node nxt, int v) = n.next |-> nxt &*& n.val |-> v;

  predicate List(Node n;) = n == null ? emp : Node(n,?h,_) &*& List(h);
  @*/

public class Node {
    Node next;
    int val;

    public Node()
    //@ requires true;
    //@ ensures Node(this, null, 0);
    {
        next = null;
        val = 0;
    }

    public void setnext(Node n)
    //@ requires Node(this, _, ?vv);
    //@ ensures Node(this, n, vv);
    {
        next = n;
    }
    public void setval(int v)
    //@ requires Node(this, ?nn, _);
    //@ ensures Node(this, nn, v);
    {
        val = v;
    }

    public Node getnext()
    //@ requires Node(this, ?nn, ?vv);
    //@ ensures Node(this, nn, vv) &*& result == nn;
    {
        return next;
    }
    public int getval()
    //@ requires Node(this, ?nn, ?vv);
    //@ ensures Node(this, nn, vv) &*& result == vv;
    {
        return val;
    }
}

class StackEmptyE extends Exception {}

/*@
  predicate StackInv(Stack s;) = s.head |-> ?h &*& List(h);

  predicate NonEmptyStack(Stack s;) = s.head |-> ?h &*& h != null &*& List(h);
  @*/

public class Stack {
    Node head;

    public Stack()
    //@ requires true;
    //@ ensures StackInv(this);
    {
        head = null;
    }

    public void push(int v)
    //@ requires StackInv(this);
    //@ ensures StackInv(this);
    {
        Node n = new Node();
        n.setval(v);
        n.setnext(head);
        head = n;
    }

    public void push_buggy(int v)
    //@ requires StackInv(this);
    //@ ensures StackInv(this);
    {
        Node n = new Node();
        n.setval(v);
        n.setnext(head);
        head = n;
    }

    public int pop()
    //@ requires StackInv(this);
    //@ ensures StackInv(this);
    {
        if(head!=null) {
            int v = head.getval();
            head = head.getnext();
            return v;
        }
        return -1; // ??? how to deal with partiality ?
    }

    public int pop_maybe()
        throws StackEmptyE //@ ensures StackInv(this);
    //@ requires StackInv(this);
    //@ ensures StackInv(this);
    {
        if(head!=null) {
            int v = head.getval();
            head = head.getnext();
            return v;
        } else throw new StackEmptyE();
    }

    public int pop_good()
    //@ requires NonEmptyStack(this);
    //@ ensures StackInv(this);
    {
        int v = head.getval();
        head = head.getnext();
        return v;
    }

    public boolean isEmpty()
    //@ requires StackInv(this);
    //@ ensures (result ? StackInv(this) : NonEmptyStack(this));
    {
        return head == null;
    }

    public void push2(int v)
    //@ requires StackInv(this);
    //@ ensures NonEmptyStack(this);
    {
        Node n = new Node();
        n.setval(v);
        n.setnext(head);
        head = n;
    }

    static void main()
    //@ requires true;
    //@ ensures true;
    {
        Stack s = new Stack();
        s.push(1);
        if (! s.isEmpty()) {
            //@ open NonEmptyStack(s);
            //@ close StackInv(s);
            s.pop();
        }
        s.push(2);
        s.push(3);
        s.pop();
    }
}
