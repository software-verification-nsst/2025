public class Account {
  int balance;
/*@
predicate AccountInv(int b) = this.balance |-> b &*& b >= 0;
@*/

  public Account()
  //@ requires true;
  //@ ensures AccountInv(0);
  {
    balance = 0;
  }
}
